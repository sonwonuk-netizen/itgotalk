# 잇고톡 개발 키트 (Claude Code 입력 자료)

한글(hwp) 기획 자료 4건과 서비스 기획서를 Claude Code가 바로 읽을 수 있는 형태로 옮긴 폴더입니다.

## 사용법
1. 이 폴더 전체를 새 Git 저장소 루트에 복사합니다.
2. 터미널에서 `claude`를 실행합니다. (CLAUDE.md는 자동으로 읽힙니다)
3. `docs/build-prompts.md`의 프롬프트를 0단계부터 순서대로 붙여 넣습니다.

## 구성
```
CLAUDE.md                        프로젝트 규칙·스택·문서 지도 (Claude Code가 자동 로드)
docs/PRD.md                      MVP 요구사항, 사용자 스토리, 수용 기준, 미결 사항
docs/learning-engine.md          진도·통과 판정 규칙, 의사코드, 테스트 케이스 12개
docs/data-model.md               엔티티 관계, CSV 매핑, 문항 표시 규칙
docs/screens.md                  화면·라우트 명세, 문항 화면 레이아웃
docs/build-prompts.md            단계별 개발 프롬프트 (0~10단계)
db/schema.sql                    PostgreSQL(Supabase) 스키마
content/skills.csv               스킬 15개 (+1~+5 도입·직관·교환법칙, 10의 보수)
content/items_addition_sum10.csv 덧셈 합 10 이하 문항 174개 (p1~p29)
content/curriculum.csv           교재 SA~SH 주차별 커리큘럼 (1~68주 + 번호 없는 6개)
```

## 원본 대비 정정한 부분 (검수 필요)
- 문항: p9~12 페이지 라벨 정정, **p21~22는 원본이 p15~16과 중복이라 +4 교환법칙 문항을 새로 작성** (note 컬럼에 표시)
- 커리큘럼: 주차 번호 56~59·50 → 46~50, '지관' → '직관', 45주 과정수학 공란 표시
- 모든 문항 정답은 계산으로 재생성해 검증함

## 먼저 정해야 할 것
`docs/PRD.md` 6장 미결 사항 Q1~Q5 (통과 시간 기준, 리포트 주기, 교사 열람 범위 등)
